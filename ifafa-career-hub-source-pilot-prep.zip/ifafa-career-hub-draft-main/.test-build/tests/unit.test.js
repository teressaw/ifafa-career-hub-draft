"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Unit tests for the rules that protect accuracy. Run with: npm test
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const status_1 = require("../src/lib/status");
const validation_1 = require("../src/lib/validation");
const filters_1 = require("../src/lib/filters");
const sample_data_1 = require("../src/lib/sample-data");
const T = '2026-11-10';
const base = { last_verified_on: '2026-11-01', dates_verified: false, opens_on: null, closes_on: null, recorded_status: null };
(0, node_test_1.test)('never verified → unverified', () => strict_1.default.equal((0, status_1.applicationStatus)({ ...base, last_verified_on: null }, T).status, 'unverified'));
(0, node_test_1.test)('verified long ago → unverified, even with verified open dates', () => strict_1.default.equal((0, status_1.applicationStatus)({ ...base, last_verified_on: '2026-06-01', dates_verified: true, opens_on: '2026-10-01', closes_on: '2026-12-31' }, T).status, 'unverified'));
(0, node_test_1.test)('verified dates → open / upcoming / closed', () => {
    strict_1.default.equal((0, status_1.applicationStatus)({ ...base, dates_verified: true, opens_on: '2026-11-01', closes_on: '2026-11-30' }, T).status, 'open');
    strict_1.default.equal((0, status_1.applicationStatus)({ ...base, dates_verified: true, opens_on: '2026-12-01' }, T).status, 'upcoming');
    strict_1.default.equal((0, status_1.applicationStatus)({ ...base, dates_verified: true, closes_on: '2026-11-09' }, T).status, 'closed');
    strict_1.default.equal((0, status_1.applicationStatus)({ ...base, dates_verified: true, closes_on: '2026-11-10' }, T).status, 'open', 'open on its closing day');
});
(0, node_test_1.test)('unverified dates are ignored', () => strict_1.default.equal((0, status_1.applicationStatus)({ ...base, dates_verified: false, opens_on: '2026-11-01', closes_on: '2026-11-30' }, T).status, 'unverified'));
(0, node_test_1.test)('recorded status used when no verified dates', () => strict_1.default.equal((0, status_1.applicationStatus)({ ...base, recorded_status: 'open' }, T).status, 'open'));
(0, node_test_1.test)('needsVerification after 120 days', () => { strict_1.default.ok((0, status_1.needsVerification)({ last_verified_on: '2026-07-01' }, T)); strict_1.default.ok(!(0, status_1.needsVerification)({ last_verified_on: '2026-10-01' }, T)); });
function fd(o) { const f = new FormData(); Object.entries(o).forEach(([k, v]) => f.set(k, v)); return f; }
const good = { employer: 'Acme', programme_name: 'Return to Work', summary: 'A programme summary.', description: 'A long enough description of the programme.', location: 'Dublin', region: 'dublin', work_arrangement: 'hybrid', programme_type: 'returnship', career_break: 'not-specified', sector: 'technology', source_url: 'https://acme.ie/careers' };
(0, node_test_1.test)('valid listing passes', () => strict_1.default.ok((0, validation_1.validateOpportunity)(fd(good)).data));
(0, node_test_1.test)('missing required fields fail', () => { const { errors } = (0, validation_1.validateOpportunity)(fd({})); for (const k of ['employer', 'programme_name', 'summary', 'description', 'location', 'region', 'source_url'])
    strict_1.default.ok(errors[k], k); });
(0, node_test_1.test)('unconfirmed dates are rejected', () => strict_1.default.ok((0, validation_1.validateOpportunity)(fd({ ...good, closes_on: '2026-12-01' })).errors.dates_verified));
(0, node_test_1.test)('dates_verified without dates is rejected', () => strict_1.default.ok((0, validation_1.validateOpportunity)(fd({ ...good, dates_verified: 'on' })).errors.dates_verified));
(0, node_test_1.test)('closing before opening is rejected', () => strict_1.default.ok((0, validation_1.validateOpportunity)(fd({ ...good, dates_verified: 'on', opens_on: '2026-12-10', closes_on: '2026-12-01' })).errors.closes_on));
(0, node_test_1.test)('non-web links are rejected', () => {
    strict_1.default.ok((0, validation_1.validateOpportunity)(fd({ ...good, source_url: 'javascript:alert(1)' })).errors.source_url);
    strict_1.default.ok((0, validation_1.validateOpportunity)(fd({ ...good, application_url: 'ftp://x.ie' })).errors.application_url);
});
(0, node_test_1.test)('unknown enum values are rejected', () => strict_1.default.ok((0, validation_1.validateOpportunity)(fd({ ...good, sector: 'astrology' })).errors.sector));
(0, node_test_1.test)('slugify', () => strict_1.default.equal((0, validation_1.slugify)('Ériu & Co.', 'Return–to–Work 2027'), 'eriu-and-co-return-to-work-2027'));
(0, node_test_1.test)('filters: unknown params ignored, status filter works', () => {
    const q = (0, filters_1.parseQuery)({ status: 'open', sector: 'not-a-sector', q: '  data  ' });
    strict_1.default.equal(q.sector, '');
    strict_1.default.equal(q.q, 'data');
    const r = (0, filters_1.applyQuery)((0, sample_data_1.sampleOpportunities)(), q);
    strict_1.default.ok(r.length >= 1 && r.every(o => o.appStatus === 'open'));
});
(0, node_test_1.test)('examples cover all four statuses', () => {
    const s = new Set((0, filters_1.applyQuery)((0, sample_data_1.sampleOpportunities)(), (0, filters_1.parseQuery)({})).map(o => o.appStatus));
    strict_1.default.deepEqual([...s].sort(), ['closed', 'open', 'unverified', 'upcoming']);
});
/* ---------- Monitoring: extraction never guesses, and always says where a value came from ---------- */
const extract_1 = require("../src/lib/monitor/extract");
const robots_1 = require("../src/lib/monitor/robots");
const jobPage = `<html><head><title>Careers | Example Ltd</title>
<script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"Organization","name":"X"},
{"@type":"JobPosting","title":"Returner Programme &ndash; Finance","hiringOrganization":{"@type":"Organization","name":"Example Ltd"},
"description":"<p>A 16-week paid returnship for people who have taken a career break. You will join the finance team.</p><p>Hybrid working.</p>",
"jobLocation":{"@type":"Place","address":{"addressLocality":"Cork","addressCountry":"IE"}},
"validThrough":"2026-12-05T23:59","url":"https://example.org/apply/123"}]}</script></head><body><p>Apply now.</p></body></html>`;
(0, node_test_1.test)('JobPosting fields are mapped with provenance', () => {
    const s = (0, extract_1.extractPage)(jobPage, 'https://example.org/careers').suggestions;
    strict_1.default.equal(s.length, 1);
    const { fields: f, provenance: p, kind } = s[0];
    strict_1.default.equal(kind, 'structured');
    strict_1.default.equal(f.programme_name, 'Returner Programme – Finance');
    strict_1.default.equal(f.employer, 'Example Ltd');
    strict_1.default.equal(f.location, 'Cork');
    strict_1.default.equal(f.region, 'cork');
    strict_1.default.equal(f.closes_on, '2026-12-05');
    strict_1.default.match(p.closes_on, /confirm/);
    strict_1.default.equal(f.application_url, 'https://example.org/apply/123');
    strict_1.default.ok(!f.description.includes('<p>'));
    for (const k of Object.keys(f))
        strict_1.default.ok(p[k], `provenance for ${k}`);
});
(0, node_test_1.test)('missing facts stay empty — no pay, no work arrangement invented', () => {
    const f = (0, extract_1.extractPage)(jobPage, 'https://example.org/careers').suggestions[0].fields;
    strict_1.default.equal(f.compensation, undefined);
    strict_1.default.equal(f.work_arrangement, undefined); // "Hybrid working" in prose is not treated as a fact
});
(0, node_test_1.test)('pages without structured data give only a basic draft', () => {
    const s = (0, extract_1.extractPage)('<title>Returners | Acme</title><meta name="description" content="Our returner programme.">', 'https://acme.example/r').suggestions;
    strict_1.default.equal(s.length, 1);
    strict_1.default.equal(s[0].kind, 'basic');
    strict_1.default.equal(s[0].fields.closes_on, undefined);
    strict_1.default.equal(s[0].fields.summary, 'Our returner programme.');
});
(0, node_test_1.test)('broken JSON-LD is ignored safely', () => {
    const s = (0, extract_1.extractPage)('<title>T</title><script type="application/ld+json">{oops</script>', 'https://a.example/').suggestions;
    strict_1.default.equal(s[0].kind, 'basic');
});
(0, node_test_1.test)('diff reports added and removed sentences', () => {
    const d = (0, extract_1.diffText)('Applications for the 2026 programme are now closed. Contact us for more information about returning.', 'Applications for the 2027 programme open on 3 February 2027. Contact us for more information about returning.');
    strict_1.default.deepEqual(d.added, ['Applications for the 2027 programme open on 3 February 2027.']);
    strict_1.default.deepEqual(d.removed, ['Applications for the 2026 programme are now closed.']);
});
(0, node_test_1.test)('date hints find dated sentences near application words only', () => {
    const h = (0, extract_1.dateHints)('We were founded on 4 May 1990. The closing date for applications is 12 December 2026. Lunch is at noon.');
    strict_1.default.deepEqual(h, ['The closing date for applications is 12 December 2026.']);
});
(0, node_test_1.test)('robots.txt: longest rule wins and our own group takes priority', () => {
    const r = (0, robots_1.robotsRules)('User-agent: *\nDisallow: /\n\nUser-agent: IFAFA-CareerHub\nDisallow: /private\nAllow: /private/careers\n');
    strict_1.default.equal((0, robots_1.robotsAllows)(r, '/careers'), true);
    strict_1.default.equal((0, robots_1.robotsAllows)(r, '/private/x'), false);
    strict_1.default.equal((0, robots_1.robotsAllows)(r, '/private/careers/returners'), true);
    const star = (0, robots_1.robotsRules)('User-agent: *\nDisallow: /search\nDisallow: /*.pdf$\n');
    strict_1.default.equal((0, robots_1.robotsAllows)(star, '/search?q=1'), false);
    strict_1.default.equal((0, robots_1.robotsAllows)(star, '/doc.pdf'), false);
    strict_1.default.equal((0, robots_1.robotsAllows)(star, '/doc.pdf.html'), true);
    strict_1.default.equal((0, robots_1.robotsAllows)((0, robots_1.robotsRules)('User-agent: *\nDisallow:\n'), '/anything'), true);
});
/* ---------- Career pathways and events/support/resources ---------- */
const filters_2 = require("../src/lib/filters");
const resources_1 = require("../src/lib/resources");
(0, node_test_1.test)('pathways: overseas needs confirmed eligibility, not just "remote"', () => {
    const o = (0, sample_data_1.sampleOpportunities)()[0];
    strict_1.default.equal(filters_2.PATHS.abroad.match({ ...o, work_arrangement: 'remote', abroad_eligibility: 'not-stated' }), false);
    strict_1.default.equal(filters_2.PATHS.abroad.match({ ...o, abroad_eligibility: 'yes' }), true);
    strict_1.default.equal(filters_2.PATHS.return.match({ ...o, programme_type: 'job' }), false);
    strict_1.default.equal(filters_2.PATHS.restart.match({ ...o, programme_type: 'job', career_break: 'not-specified' }), false);
    strict_1.default.equal((0, filters_1.parseQuery)({ path: 'nonsense' }).path, '');
    strict_1.default.ok((0, filters_1.applyQuery)((0, sample_data_1.sampleOpportunities)(), (0, filters_1.parseQuery)({ path: 'return' }), T).every(x => ['returnship', 'reentry'].includes(x.programme_type)));
});
const rfd = (o) => { const f = new FormData(); for (const [k, v] of Object.entries(o))
    for (const x of [v].flat())
        f.append(k, x); return f; };
const okRes = { kind: 'event', title: 'Returners webinar', provider: 'A provider', summary: 'A short summary of it.', url: 'https://example.org/e' };
(0, node_test_1.test)('resources: event dates are dropped unless confirmed', () => {
    const r = (0, resources_1.validateResource)(rfd({ ...okRes, event_date: '2026-12-01' }), T);
    strict_1.default.equal(r.data?.event_date, null);
    const c = (0, resources_1.validateResource)(rfd({ ...okRes, event_date: '2026-12-01', date_verified: 'on' }), T);
    strict_1.default.equal(c.data?.event_date, '2026-12-01');
    strict_1.default.ok((0, resources_1.validateResource)(rfd({ ...okRes, date_verified: 'on' }), T).errors?.event_date);
});
(0, node_test_1.test)('resources: rejects bad links and unknown audiences are ignored', () => {
    strict_1.default.ok((0, resources_1.validateResource)(rfd({ ...okRes, url: 'javascript:alert(1)' }), T).errors?.url);
    strict_1.default.deepEqual((0, resources_1.validateResource)(rfd({ ...okRes, kind: 'support', audiences: ['return', 'everyone'] }), T).data?.audiences, ['return']);
    strict_1.default.equal((0, resources_1.validateResource)(rfd({ ...okRes, kind: 'support', event_date: '2026-12-01', date_verified: 'on' }), T).data?.event_date, null);
});
(0, node_test_1.test)('resources: no audiences means relevant to every path', () => {
    strict_1.default.equal((0, resources_1.forPath)({ audiences: [] }, 'abroad'), true);
    strict_1.default.equal((0, resources_1.forPath)({ audiences: ['return'] }, 'abroad'), false);
    strict_1.default.equal((0, resources_1.forPath)({ audiences: ['return'] }, ''), true);
});
