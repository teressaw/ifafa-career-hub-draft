import 'server-only';
import type { DraftSuggestion } from './extract';

/** Official Greenhouse public job-board JSON API. Only explicitly configured boards are queried. */
type Job = { id: number; title: string; absolute_url: string; location?: { name?: string }; content?: string; updated_at?: string };
const ireland = /\b(ireland|dublin|cork|galway|limerick|waterford|kilkenny|wicklow|kildare|meath|sligo|louth|donegal|tipperary)\b/i;
const overseas = /\b(london|united states|new york|berlin|paris|singapore|australia)\b/i;
const reentry = /\b(returnship|return to work|career re.?entry|career restart|career break|apprentice|trainee|graduate|entry.level)\b/i;
const irrelevant = /\b(senior director|vice president|chief executive|chief technology officer)\b/i;
/** Prioritise re-entry and accessible roles before AI screening; human review remains mandatory. */
export function rankGreenhouseCandidates<T extends { fields: { programme_name?: string } }>(candidates: T[]): T[] {
  const score = (s: T) => { const title = s.fields.programme_name ?? ''; return (reentry.test(title) ? 10 : 0) - (irrelevant.test(title) ? 5 : 0); };
  return [...candidates].sort((a, b) => score(b) - score(a));
}
export function greenhouseSuggestion(board: string, job: Job): DraftSuggestion | null {
  if (!Number.isSafeInteger(job.id) || !job.title || !job.absolute_url?.startsWith('https://')) return null;
  const location = job.location?.name?.trim() ?? '';
  // Exclude vague 'remote' positions: remote does not mean work-from-Ireland.
  if (!ireland.test(location) || overseas.test(location)) return null;
  const employer = board.replace(/[-_]/g, ' ');
  const summary = (job.content ?? '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 400);
  return { kind: 'structured', fields: { employer, programme_name: job.title.slice(0, 160), location, region: 'ireland', summary, application_url: job.absolute_url, source_url: job.absolute_url }, provenance: { employer: `Greenhouse board identifier: ${board} (verify employer name)`, programme_name: 'Greenhouse API title', location: 'Greenhouse API location; verify actual work location', region: 'Location keyword filter; unverified', summary: 'Greenhouse API description', application_url: 'Greenhouse API absolute_url', source_url: 'Greenhouse API absolute_url' } };
}
export async function discoverGreenhouse(board: string): Promise<DraftSuggestion[]> {
  if (!/^[a-zA-Z0-9_-]{2,80}$/.test(board)) throw new Error('Invalid board identifier');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const res = await fetch(`https://boards-api.greenhouse.io/v1/boards/${board}/jobs?content=true`, { signal: controller.signal, headers: { accept: 'application/json' }, cache: 'no-store' });
    if (!res.ok) throw new Error(`Greenhouse API HTTP ${res.status}`);
    const json: unknown = await res.json();
    if (!json || typeof json !== 'object' || !('jobs' in json) || !Array.isArray(json.jobs)) throw new Error('Unexpected Greenhouse response');
    return rankGreenhouseCandidates((json.jobs as Job[]).slice(0, 300).map(j => greenhouseSuggestion(board, j)).filter((s): s is DraftSuggestion => s !== null)).slice(0, 15);
  } finally { clearTimeout(timer); }
}
