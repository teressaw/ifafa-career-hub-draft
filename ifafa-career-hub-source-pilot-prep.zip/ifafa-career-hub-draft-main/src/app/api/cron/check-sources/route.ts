import { timingSafeEqual } from 'node:crypto';
import { createClient } from '@supabase/supabase-js';
import { supabaseConfig } from '@/lib/supabase/config';
import { checkPage } from '@/lib/monitor/check';
import { recordCheck } from '@/lib/monitor/record';
import { discoverGreenhouse } from '@/lib/monitor/greenhouse';
import { triageSuggestion } from '@/lib/monitor/ai-triage';

/**
 * OPTIONAL scheduled check of watched sources (see vercel.json and the README).
 * Runs only when CRON_SECRET and SUPABASE_SECRET_KEY are both set on the server. The secret key
 * bypasses row-level security, so it is used here and nowhere else, and is never sent to a browser.
 * It only updates sources and adds suggestions — it never creates or publishes listings.
 */
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

function authorised(req: Request) {
  const secret = process.env.CRON_SECRET;
  const got = req.headers.get('authorization') ?? '';
  const want = `Bearer ${secret}`;
  return !!secret && got.length === want.length && timingSafeEqual(Buffer.from(got), Buffer.from(want));
}

export async function GET(req: Request) {
  if (!authorised(req)) return Response.json({ error: 'Not authorised' }, { status: 401 });
  const cfg = supabaseConfig(), key = process.env.SUPABASE_SECRET_KEY;
  if (!cfg || !key) return Response.json({ skipped: 'Scheduled checks are not configured.' });

  const db = createClient(cfg.url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data, error } = await db.from('sources').select('id,url,content_hash,snapshot,check_every_days,last_checked_at').eq('active', true).order('last_checked_at', { ascending: true, nullsFirst: true });
  if (error) return Response.json({ error: error.message }, { status: 500 });

  const now = Date.now(), started = now, results: { id: string; status: string }[] = [];
  const due = (data ?? []).filter(s => !s.last_checked_at || now - Date.parse(s.last_checked_at) >= s.check_every_days * 86_400_000 - 3_600_000);
  for (const s of due) {
    if (Date.now() - started > 45_000) break; // leave the rest for tomorrow
    const r = await checkPage(s.url, { hash: s.content_hash, snapshot: s.snapshot });
    try { await recordCheck(db, s.id, r, null); results.push({ id: s.id, status: r.status }); }
    catch (e) { results.push({ id: s.id, status: 'save-failed: ' + (e as Error).message }); }
    await new Promise(res => setTimeout(res, 1000)); // one page at a time, politely
  }
  // Optional discovery feed: official Greenhouse job-board API. Requires explicit board IDs and AI screening.
  // Discovery is bounded by the cron runtime and never publishes a listing.
  const discovered: { board: string; found: number; queued: number; error?: string }[] = [];
  const boards = [...new Set((process.env.IFAFA_GREENHOUSE_BOARDS ?? '').split(',').map(s => s.trim()).filter(Boolean))].slice(0, 3);
  if (process.env.OPENAI_API_KEY) for (const board of boards) {
    if (Date.now() - started > 43_000) break;
    try {
      const candidates = await discoverGreenhouse(board);
      let queued = 0;
      for (const candidate of candidates.slice(0, 5)) {
        if (Date.now() - started > 48_000) break;
        const assessment = await triageSuggestion(candidate);
        if (assessment?.decision !== 'review') continue; // fail closed
        const url = candidate.fields.application_url!;
        const { error: saveError } = await db.from('suggestions').upsert({
          url, dedupe_key: `greenhouse:${board}:${url}`.slice(0, 500), kind: 'structured',
          fields: candidate.fields, provenance: { ...candidate.provenance, _ai_review: assessment },
        }, { onConflict: 'dedupe_key', ignoreDuplicates: true });
        if (saveError) throw new Error(saveError.message);
        queued++;
      }
      discovered.push({ board, found: candidates.length, queued });
    } catch (e) { discovered.push({ board, found: 0, queued: 0, error: (e as Error).message }); }
  }
  return Response.json({ checked: results.length, due: due.length, results, discovered });
}
